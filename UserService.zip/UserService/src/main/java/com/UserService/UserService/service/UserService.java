package com.UserService.UserService.service;

import com.UserService.UserService.Exception.ResourceNotFoundException;
import com.UserService.UserService.entities.User;
import com.UserService.UserService.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public User saveUser(User user){
        String randomUUID= UUID.randomUUID().toString();
        user.setUserId(randomUUID);
       return userRepository.save(user);
    }

    public List<User> getAllUser(){
        return userRepository.findAll();
    }

    public User getUser(String userId){
        return userRepository.findById(userId).orElseThrow(()-> new ResourceNotFoundException("User Not Found wityh Id :"+ userId));
    }

}
